
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import groovy.transform.CompileStatic


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 * @deprecated Please use internal.GlobalVariable instead
 */
@Deprecated
@CompileStatic
public class GlobalVariable {
	 
    /**
     * <p></p>
     */
	public static Object G_Timeout = 10
	 
    /**
     * <p></p>
     */
	public static Object G_SiteURL = 'http://demoaut.katalon.com'
	 
    /**
     * <p></p>
     */
	public static Object G_ShortTimeOut = 5
	 
}
