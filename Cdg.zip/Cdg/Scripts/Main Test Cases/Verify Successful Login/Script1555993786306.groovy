import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS

WebUI.verifyElementVisible(findTestObject('Home and login page/SECTION_PRODUCT_PAGE'))

WebUI.verifyElementVisible(findTestObject('Home and login page/Content_Product List'))

WebUI.verifyElementVisible(findTestObject('Home and login page/Verify_Addproduct_Text'))

WebUI.verifyElementVisible(findTestObject('Home and login page/Close_Add_Product'))

//WebUI.verifyElementVisible(findTestObject('Home and login page/Dropdown User'))

WebUI.scrollToElement(findTestObject('Home and login page/Privacy_Policy'), 6)

WebUI.verifyElementVisible(findTestObject('Home and login page/Copyright'))

WebUI.verifyElementVisible(findTestObject('Home and login page/Privacy_Policy'))

WebUI.verifyElementVisible(findTestObject('Home and login page/Terms_of_Use'))

