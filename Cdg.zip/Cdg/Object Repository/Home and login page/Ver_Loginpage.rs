<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Ver_Loginpage</name>
   <tag></tag>
   <elementGuidId>90c599b2-b6df-4a5e-a040-0b7e7da103af</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>contains</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>Sign In</value>
   </webElementProperties>
</WebElementEntity>
