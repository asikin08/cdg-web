<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Short By</name>
   <tag></tag>
   <elementGuidId>403a35fb-d5c5-432f-b9b3-7e4b573cb09c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;ticket&quot;]/div/div[3]/div[2]/div/div/span/span[1]/span</value>
   </webElementProperties>
</WebElementEntity>
